#include <vector>
#include <string>
#ifndef TRIE_H
#define TRIE_H
struct node {
    std::vector<struct node*> hijos;
    char letras;
    int tam;
};
#endif

using namespace std;

class Trie{
	private:
		node* arbol;
		node* crearNodo(char caracter);
		node* obtenerNodo(int pos, vector<struct node*> nivel);
		void borrarArbol(vector<struct node*> nivel);
		bool nodoCheck(vector<struct node*> nivel);
	public:
		
		Trie();
		~Trie();
		void insert(string s,int frecuencia);
		//void pop();
		//int at(int pos);
		//int size();
};
