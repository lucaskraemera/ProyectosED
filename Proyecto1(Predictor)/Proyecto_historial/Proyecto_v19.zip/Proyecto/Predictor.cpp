#include "Predictor.h"
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

Predictor::Predictor(){
	//cout << "Predictor" << endl;
	t = new Trie();
}
Predictor::~Predictor(){
	delete t;
}

void Predictor::insert(string s,int frecuencia){
	//cout << "insert del predictor" << endl;
	s+='$';
	//cout << s << endl;
	t->insert(s,frecuencia);
	//cout << "termino insert del predictor" << endl;
	
	//t->verTrie();
}

void Predictor::ordenarArr(vector<stringConFrecuencia>* scf){
	if(scf->size()==0) return;
	for(int i=0;i<scf->size();i++){ //ordenar
		int menor = i;
		for(int j = i+1;j<scf->size();j++){
			if (scf->at(menor).frecuencia < scf->at(j).frecuencia) menor = j;
			else if(scf->at(menor).frecuencia == scf->at(j).frecuencia && scf->at(menor).s.compare(scf->at(j).s) > 0){
				menor = j;
				//cerr << "menor" << menor << " j" << j << endl;
			} 
		}
		stringConFrecuencia aux;
		aux=scf->at(i);
		scf->at(i) = scf->at(menor);
		scf->at(menor) = aux;
	}
}

vector<string> Predictor::busqueda(string aBuscar,int k){
	int aux= aBuscar.size()+1;
	vector<string> resultado;
	vector<stringConFrecuencia> scf;
	do{
		aux--;
		node* nivel = t->nodoMasCercano(aBuscar,&aux);
		string stringAuxiliar;
		for(int i=0; i<aux; i++){
			stringAuxiliar+=aBuscar[i];
		}
		scf = t->obtenerStrings(stringAuxiliar,nivel);
	}while(k>scf.size());
	ordenarArr(&scf);
	
	cerr << "scf: " << aBuscar << endl;
	for(int i=0;i<scf.size();i++){
		cerr << scf[i].s << scf[i].frecuencia << " ";
	}
	cerr << endl;
	
	for(int i = 0; i<k;i++){ // insertar los datos en el vector resultado y aumentar las frecuencias seleccionadas
		resultado.push_back(scf[i].s);
		t->aumentarFrecuencia(scf[i].s);
	}
	
	for(int i = 0; i< resultado.size();i++){
		cerr << resultado[i] << " ";
	}
	cerr << endl;
	
	return resultado;
}

