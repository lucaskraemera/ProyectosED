#include "Trie.h"
#include <string>
#include <iostream>

using namespace std;

Trie::Trie(){
	this->arbol = new node();
	arbol->hijos.assign('z'-'a'+2,NULL);
	arbol->letras = '&'; // nose como inicializarlo xd
	arbol->tam=0;
}

Trie::~Trie(){ // falta arreglar
	if(arbol!=NULL){
		borrarArbol(arbol);	
	}
	delete arbol;
}

void Trie::borrarArbol(node* nivel){
	//cerr << nivel->letras;
	//while(!this->nodoCheck()){
		for(int i=0; i<nivel->hijos.size(); i++){
			if(nivel->hijos[i]!=NULL){
				borrarArbol(nivel->hijos[i]);
				delete nivel->hijos[i];	
				//nivel->hijos[i] = NULL;
			} 
		}
	//}	
}

bool Trie::nodoCheck(node* nivel){
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL) return false;
	}
	return true;
}

node* Trie::crearNodo(char caracter){
	node* puntero= new node();
	puntero->hijos.assign('z'-'a'+2,NULL);
	//cout << endl << "crea nodo con letra: " << caracter << endl;
	puntero->letras =  caracter;
	puntero->tam=0;
	return puntero;
}

node* Trie::obtenerNodo(int pos,node* nivel){
	node* puntero = nivel->hijos[pos];
	if(puntero==NULL) return NULL;
	else return puntero;
}

void Trie::insert(string s,int frecuencia){
	node* aux; // nodo auxiliar de comparacion
	node* nivel = arbol; // nivel del vector en el que nos encontramos
	cout << "paso declaracion de variables del insert del trie" << endl;
	
	for(int i=0;i<s.size();i++){ // vector contiene en 0 '$' y de 1-26 a-z
		int pos = s[i] - 'a' + 1; // para saber la ubicacion en donde se encuentra la letra
		if(s[i] == '$') pos = 0;
		//cout << "pos: " << pos << endl;
		aux = obtenerNodo(pos,nivel); // revisa si hay un nodo en la pos 
		cout << "nivel: " << i+1 << " caracter a insertar: " << s[i] << endl;
		//cout << "arreglo: ";
		if(aux==NULL) nivel->hijos[pos] = crearNodo(s[i]); // caso que no habia un nodo se crea uno
		else nivel->hijos[pos]=aux; // caso contrario, se aprovecha de que el nodo ya existe (no lo sobreescribe)
		cout << endl;
		nivel=nivel->hijos[pos]; // asignar el siguiente nivel de la letra
	}
	nivel->tam = frecuencia; // asignarle la frecuencia adecuada
	cout << "se inserto correctamente la palabra" << endl;
}

node* Trie::nodoMasCercano(string s){
	node* nivel = arbol;
	node* aux;
	for(int i=0;i<s.size();i++){
		int pos = s[i] - 'a' + 1;
		aux = obtenerNodo(pos,nivel);
		if(aux == NULL) return nivel;
		nivel = aux;
	}
	return nivel;
}

void Trie::imprimirLetras(node* nivel){
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL) cout << nivel->hijos[i]->letras << " ";
	}
	cout << endl;
}

void Trie::ordenarArr(){
	
}

void Trie::busqueda(string s,int k){
	node* nivel = nodoMasCercano(s);
	
	//crea un arreglo de strings desde la palabra mas usada(izquierda) a la menos usada 
	// esto se puede hacer dsps de recojer todas las palabras, simplemente comparo su frecuencia
	// (podria hacer un arreglo que guarde una structura con string y frecuencia)
	/* esto lo dejo pq es super util para saber el termino de palabra y segun la string que utilizo
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL){
			imprimirLetras(nivel);
			string sl = string(1,nivel->hijos[i]->letras);
			aux += sl;	
			revisarTrie(nivel->hijos[i],aux);
			aux.pop_back();
		} 
	}
	*/
}

void Trie::revisarTrie(node* nivel,string aux){
	cout << "nivel " << aux.size() << endl << "string ahora: " << aux << ":" << endl;
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL){
			imprimirLetras(nivel);
			string sl = string(1,nivel->hijos[i]->letras);
			aux += sl;	
			revisarTrie(nivel->hijos[i],aux);
			aux.pop_back();
		} 
	}
}

void Trie::verTrie(){
	string aux;
	revisarTrie(arbol,aux);
}
