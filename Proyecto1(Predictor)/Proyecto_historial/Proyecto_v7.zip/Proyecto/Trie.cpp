#include "Trie.h"
#include <string>
#include <iostream>

using namespace std;

Trie::Trie(){
	this->arbol = new node();
	arbol->hijos.assign(27,NULL);
	//arbol->letras = NULL; // nose como inicializarlo xd
	arbol->tam=0;
}

Trie::~Trie(){
	// despues nos preocupamos del destructor
}

node* Trie::crearNodo(char caracter){
	node* puntero= new node();
	puntero->hijos.assign(27,NULL);
	cout << "crea nodo con letra: " << caracter << endl;
	//puntero->letras = NULL; // nose como inicializarlo xd
	puntero->tam=0;
	return puntero;
}

node* Trie::obtenerNodo(int pos,vector<struct node*> nivel){
	node* puntero = nivel[pos];
	if(puntero==NULL) return NULL;
	else return puntero;
}

void Trie::insert(string s,int frecuencia){
	node* aux; // nodo auxiliar de comparacion
	vector<struct node*> nivel = arbol->hijos; // nivel del vector en el que nos encontramos
	cout << "paso declaracion de variables del insert del trie" << endl;
	
	for(int i=0;i<s.size();i++){ // vector va desde 0-25 a-z y el 26 es '$'
		int pos = s[i] - 'a'; // para saber la ubicacion en donde se encuentra la letra
		aux = obtenerNodo(pos,nivel); // revisa si hay un nodo en la pos 
		if(aux==NULL) nivel[pos] = crearNodo(s[i]); // caso que no habia un nodo se crea uno
		else nivel[pos]=aux; // caso contrario, se aprovecha de que el nodo ya existe (no lo sobreescribe)
		nivel=nivel[pos]->hijos; // asignar el siguiente nivel de la letra
	}
	nivel[27] = crearNodo('$'); // crear el nodo de '$'
	nivel[27]->tam = frecuencia; // asignarle la frecuencia adecuada
	cout << "se inserto correctamente la palabra" << endl;
}
