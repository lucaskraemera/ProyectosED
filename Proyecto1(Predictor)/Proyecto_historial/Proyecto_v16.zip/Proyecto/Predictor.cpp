#include "Predictor.h"
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

Predictor::Predictor(){
	//cout << "Predictor" << endl;
	t = new Trie();
}
Predictor::~Predictor(){
	delete t;
}

void Predictor::insert(string s,int frecuencia){
	cout << "insert del predictor" << endl;
	s+='$';
	cout << s;
	t->insert(s,frecuencia);
	cout << "termino insert del predictor" << endl;
	
	//t->verTrie();
}

string* Predictor::busqueda(string aBuscar,int k){
	vector<string> resultados = t->busqueda(aBuscar,k);
	for(int i = 0; i< resultados.size();i++){
		cerr << resultados[i] << " ";
	}
	cerr << endl;
}

void Predictor::imprimirResultados(ofstream archivoSalida){
	
}
