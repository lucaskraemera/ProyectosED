#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Controladora.h"

using namespace std;

int main(int argc, char **argv){
	//cout << "hola" << endl;
	if (argc!=5)
    {
        printf("Debes entregar 4 parametros\n");
        return 1;
    }
    cout << endl << "nombre de archivos entregados:" << endl;
    cout << argv[1] << endl;
    cout << argv[2] << endl;
    cout << argv[3] << endl;
    cout << argv[4] << endl << endl;
    
	ifstream entrada;
	ifstream busqueda;
	ofstream salida;
	
	//asegurarse de que vengan los archivos requeridos
	busqueda.open(argv[2]);
	if(!busqueda){
		cout << "falta archivo de cadanas a buscar" << endl;
		return 0;
	}
	entrada.open(argv[1]);
	if(!entrada){
		cout << "falta archivo de diccionario" << endl;
		return 0;
	}
	salida.open(argv[3]);

	int k = stoi(argv[4]);
	
	Controladora* control = new Controladora();
	control->lecturaDiccionario(entrada);
	control->busqueda(busqueda,salida,k);

	cout << endl << "Lectura de entrada:" << endl;
	
	cout << "Pre delete control" << endl;
	delete control;
	cout << "Post delete control" << endl;
	
	entrada.close();
	busqueda.close();
	salida.close();
	
	cout << "El proceso termino correctamente" << endl;
	
    return 0;   
} 
