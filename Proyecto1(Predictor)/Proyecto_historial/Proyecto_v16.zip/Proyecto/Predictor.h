#include <string>
#include "Trie.h"

using namespace std;

class Predictor{
	private:
		Trie* t;
	public:
		Predictor();
		~Predictor();
		void insert(string s,int frecuencia);
		string* busqueda(string aBuscar,int k);
		void imprimirResultados(ofstream archivoSalida);
};
