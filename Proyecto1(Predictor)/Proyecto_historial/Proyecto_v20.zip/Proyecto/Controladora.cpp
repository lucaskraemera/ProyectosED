#include "Controladora.h"
#include <fstream>
#include <iostream>
#include<string>
#include<vector>

using namespace std;

Controladora::Controladora(char* diccionario,char* archivoBusqueda, char* resultados,int ka){
	//cout << "Controladora" << endl;
	this->pred = new Predictor();
	this->diccionario.open(diccionario);
	this->archivoBusqueda.open(archivoBusqueda);
	this->archivoSalida.open(resultados);
	this->k = ka;
}

Controladora::~Controladora(){
	delete pred;
}

void Controladora::busqueda(){
	string aBuscar;
	vector<string> resultados;
	while(!archivoBusqueda.eof()){
		archivoBusqueda >> aBuscar;
		resultados = pred->busqueda(aBuscar,k);
		imprimirResultados(resultados, aBuscar);	
	}
	
}

void Controladora::lecturaDiccionario(){
	string palabra, aux;
	int frecuencia;
	while(!diccionario.eof()){ //FALTA COLOCAR LA IGNORACION DE LA LECTURA DE COMENTARIOS
		diccionario >> palabra;
		frecuencia = rand()%1001;
		//cout << palabra << endl;
		//cout << aux << endl;
		//cout << endl;
		pred->insert(palabra,frecuencia);
		//cout << "termino insert de controladora" << endl;
	}
	
}

void Controladora::imprimirResultados(vector<string> resultados,string aBuscar){
	archivoSalida << "resultados de " << aBuscar << ":" << "\n";
	for(int i=0; i < resultados.size(); i++){
		archivoSalida << resultados[i] << "\n";
	}
	archivoSalida << "\n";
}
