#include <vector>
#include <string>
#ifndef TRIE_H
#define TRIE_H
struct node {
    std::vector<struct node*> hijos;
    char letras;
    int tam;
};

struct stringConFrecuencia {
    std::string s;
    int frecuencia;
};
#endif

using namespace std;

class Trie{
	private:
		node* arbol;
		node* crearNodo(char caracter);
		node* obtenerNodo(int pos, node* nivel);
		void borrarArbol(node* nivel);
		bool nodoCheck(node* nivel);
		void revisarTrie(node* nivel,string aux);
		void imprimirLetras(node* nivel);
		void ordenarArr(stringConFrecuencia* scf);
		void aumentarFrecuencia(string s);
		node* nodoMasCercano(string abuscar,int* aux);
		stringConFrecuencia* obtenerStrings(int* size);
	public:
		Trie();
		~Trie();
		void insert(string s,int frecuencia);
		void verTrie();
		string* busqueda(string aux,int k);
};
