#include "Predictor.h"
#include<fstream>

class Controladora{
	private:
		void imprimirResultados(ofstream archivoSalida);
		Predictor* pred;
	public: 
		Controladora();
		~Controladora();
		void lecturaDiccionario(ifstream & diccionario);
		void busqueda(ifstream & cadena, ofstream & archivoSalida);
		//void pop();
		//int at(int pos);
		//int size();
};
