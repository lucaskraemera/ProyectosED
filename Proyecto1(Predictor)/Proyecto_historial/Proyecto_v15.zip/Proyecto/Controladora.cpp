#include "Controladora.h"
#include <fstream>
#include <iostream>

using namespace std;

Controladora::Controladora(){
	//cout << "Controladora" << endl;
	pred = new Predictor();
}

Controladora::~Controladora(){
	delete pred;
}

void Controladora::busqueda(ifstream & cadena, ofstream & archivoSalida){
}

void Controladora::lecturaDiccionario(ifstream & diccionario){
	string palabra, aux;
	int frecuencia;
	while(!diccionario.eof()){
		diccionario >> palabra;
		diccionario >> aux;
		frecuencia = stoi(aux);
		cout << palabra << endl;
		cout << aux << endl;
		//cout << endl;
		pred->insert(palabra,frecuencia);
		cout << "termino insert de controladora" << endl;
	}
	
}

void imprimirResultados(ofstream archivoSalida){
	archivoSalida;
}
