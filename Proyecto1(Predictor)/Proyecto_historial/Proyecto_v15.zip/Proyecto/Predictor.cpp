#include "Predictor.h"
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

Predictor::Predictor(){
	//cout << "Predictor" << endl;
	t = new Trie();
}
Predictor::~Predictor(){
	delete t;
}

void Predictor::insert(string s,int frecuencia){
	cout << "insert del predictor" << endl;
	s+='$';
	cout << s;
	t->insert(s,frecuencia);
	cout << "termino insert del predictor" << endl;
	
	//t->verTrie();
}

string* Predictor::busqueda(string aBuscar){
	//resibe string a buscar y lo busca en el trie, el trie retornara un arreglo con
	//todas las palabras cercanas a esa string y analizara, creara un arreglo con las k mas cercanas
	// y hara return de ese arreglo
}

void Predictor::imprimirResultados(ofstream archivoSalida){
	
}
