#include "Trie.h"
#include <string>
#include <iostream>

using namespace std;

Trie::Trie(){
	this->arbol = new node();
	arbol->hijos.assign(27,NULL);
	//arbol->letras = NULL; // nose como inicializarlo xd
	arbol->tam=0;
}

Trie::~Trie(){
	// despues nos preocupamos del destructor
}

node* Trie::crearNodo(char caracter){
	node* puntero= new node();
	puntero->hijos.assign(27,NULL);
	cout << caracter << endl;
	//puntero->letras = NULL; // nose como inicializarlo xd
	puntero->tam=0;
	return puntero;
}

void Trie::desplazarVector(int j, vector<struct node*>* vec){
	int n=vec->size();
	cout << "desplazar vector vec.size(): " << n << endl;
	for(n;n>j;n--){
		vec[n]=vec[n-1];
	}
	cout << "se desplazo el vec" << endl;
}

void Trie::insert(string s,int frecuencia){
	string sl; // string utilizada para ver el caracter de s como string para el metodo compare
	string aux; // el caracter a comparar del node
	int i,j; // declare los int pq tal vez los use afuera del for (solo el j pero declare el i igual porsiacaso)
	vector<struct node*> nivel = arbol->hijos; // nivel del vector en el que nos encontramos
	cout << "paso declaracion de variables del insert del trie" << endl;
	for(i=0;i<s.size();i++){ // recorrer a nivel de vector
		sl=s[i]; // tomar el caracter del string s a asignar/insertar
		cout << "sl: " << sl << endl;
		cout << "i: " << i << endl;
		cout <<"nivel.size(): " <<nivel.size() << endl;
		for(j=0;j<nivel.size();j++){ // recorrer las letras dentro del nivel de vector que estamos
			cout << "j: " << j << endl;
			if(j == NULL){
				cout << "NULL" << endl;
				char caracter = sl[0];
				nivel[j] = crearNodo(caracter);	
				cout << "se creo un nodo en pos " << j << endl;
				break;
			}
			cout << "no NULL" << endl;
			aux = nivel[j]->letras; // ver la letra que esta ocupando el nodo
			//comparacion de caracteres
			if(sl.compare(aux) > 0)  continue; // sigamos, vamos en el orden correcto
			else if(sl.compare(aux) == 0) break; // las letras son las mismas, por lo que solo tenemos que seguir de nivel
			else{
				desplazarVector(j,&nivel);
				char caracter =sl[0];
				nivel[j] = crearNodo(caracter);	
				break;
			}// caso que es menor (desplaszar todo a la derecha y colocarlo ahi)
		}
		cout << "mankk gamer" << endl;
		nivel = nivel[j]->hijos; // pasar al siguiente nivel para la comparacion (estos fueron definidos en el for anterior)
		cout << "asignar nivel completado para " << i << endl;
	}
	cout << "paso for del insert del trie" << endl;
	// asignacion de caracter peso que siempre va al comienzo del arreglo y como estamos leyendo del diccionario, este nunca se va a encontrar anteriormente en el arreglo
	sl = '$'; 
	vector<struct node*>* puntero = &nivel;
	cout << "wena compadre" << endl;
	desplazarVector(0,puntero);
	cout << "prueba" << endl;
	cout << "nivel.size(): " << nivel.size() << endl;
	nivel[0] = crearNodo(sl[0]);
	cout << "se creo el nodo '$'" << endl;
	nivel[0]->tam = frecuencia;
	cout << "insertado correctamente la palabra" << endl;
}
