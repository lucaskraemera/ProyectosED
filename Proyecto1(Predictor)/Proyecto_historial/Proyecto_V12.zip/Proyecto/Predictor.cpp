#include "Predictor.h"
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

Predictor::Predictor(){
	//cout << "Predictor" << endl;
	t = new Trie();
}
Predictor::~Predictor(){
	delete t;
}

void Predictor::insert(string s,int frecuencia){
	cout << "insert del predictor" << endl;
	s+='$';
	cout << s;
	t->insert(s,frecuencia);
	cout << "termino insert del predictor" << endl;
	
	t->verTrie();
	/*
	cout << "nivel 1 del arreglo: ";
	for(int i =0;i < t->arbol->hijos.size(); i++){
		if(i==0) cout << "entro al for con i del predictor" << endl;
		node* aux = t->arbol;
		//cout << "es la comparacion" << endl;
		if(aux->hijos[i]!=NULL) cout << aux->hijos[i]->letras << " ";//cout << t->arbol->hijos[i]->letras << " a";
	}
	cout << endl << "fin del nivel 1 del arreglo" << endl;
	*/
}

string* Predictor::busqueda(string aBuscar){
	
}

void Predictor::imprimirResultados(ofstream archivoSalida){
	
}
