#include "Trie.h"
#include <string>
#include <iostream>

using namespace std;

Trie::Trie(){
	this->arbol = new node();
	arbol->hijos.assign('z'-'a'+2,NULL);
	arbol->letras = '&'; // nose como inicializarlo xd
	arbol->tam=0;
}

Trie::~Trie(){ // falta arreglar
	if(arbol!=NULL){
		borrarArbol(arbol);	
	}
	delete arbol;
}

void Trie::borrarArbol(node* nivel){
	//cerr << nivel->letras;
	//while(!this->nodoCheck()){
		for(int i=0; i<nivel->hijos.size(); i++){
			if(nivel->hijos[i]!=NULL){
				borrarArbol(nivel->hijos[i]);
				delete nivel->hijos[i];	
				//nivel->hijos[i] = NULL;
			} 
		}
	//}	
}

bool Trie::nodoCheck(node* nivel){
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL) return false;
	}
	return true;
}

node* Trie::crearNodo(char caracter){
	node* puntero= new node();
	puntero->hijos.assign('z'-'a'+2,NULL);
	//cout << endl << "crea nodo con letra: " << caracter << endl;
	puntero->letras =  caracter;
	puntero->tam=0;
	return puntero;
}

node* Trie::obtenerNodo(int pos,node* nivel){
	node* puntero = nivel->hijos[pos];
	if(puntero==NULL) return NULL;
	else return puntero;
}

void Trie::insert(string s,int frecuencia){
	node* aux; // nodo auxiliar de comparacion
	node* nivel = arbol; // nivel del vector en el que nos encontramos
	//cout << "paso declaracion de variables del insert del trie" << endl;
	
	for(int i=0;i<s.size();i++){ // vector contiene en 0 '$' y de 1-26 a-z
		int pos = s[i] - 'a' + 1; // para saber la ubicacion en donde se encuentra la letra
		if(s[i] == '$') pos = 0;
		//cout << "pos: " << pos << endl;
		aux = obtenerNodo(pos,nivel); // revisa si hay un nodo en la pos 
		//cout << "nivel: " << i+1 << " caracter a insertar: " << s[i] << endl;
		//cout << "arreglo: ";
		if(aux==NULL) nivel->hijos[pos] = crearNodo(s[i]); // caso que no habia un nodo se crea uno
		else nivel->hijos[pos]=aux; // caso contrario, se aprovecha de que el nodo ya existe (no lo sobreescribe)
		//cout << endl;
		nivel=nivel->hijos[pos]; // asignar el siguiente nivel de la letra
	}
	nivel->tam = frecuencia; // asignarle la frecuencia adecuada
	//cout << "se inserto correctamente la palabra" << endl;
}

node* Trie::nodoMasCercano(string s,int* aux){
	node* nivel = arbol;
	node* auxNodo;
	int nivelActual=0;
	for(int i=0;i<*aux;i++){
		int pos = s[i] - 'a' + 1;
		auxNodo = obtenerNodo(pos,nivel);
		if(auxNodo == NULL){
			*aux = nivelActual;
			return nivel;	
		} 
		nivelActual++;
		nivel = auxNodo;
	}
	return nivel;
}

void Trie::imprimirLetras(node* nivel){
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL) cout << nivel->hijos[i]->letras << " ";
	}
	cout << endl;
}

void Trie::ordenarArr(vector<stringConFrecuencia>* scf){
	if(scf->size()==0) return;
	for(int i=0;i<scf->size();i++){ //ordenar
		int menor = i;
		for(int j = i+1;j<scf->size();j++){
			if (scf->at(menor).frecuencia < scf->at(j).frecuencia) menor = j;
			else if(scf->at(menor).frecuencia == scf->at(j).frecuencia && scf->at(menor).s.compare(scf->at(j).s) > 0){
				menor = j;
				//cerr << "menor" << menor << " j" << j << endl;
			} 
		}
		stringConFrecuencia aux;
		aux=scf->at(i);
		scf->at(i) = scf->at(menor);
		scf->at(menor) = aux;
	}
}

void Trie::aumentarFrecuencia(string s){
	node* nivel = arbol;
	for(int i=0;i<s.size();i++){
		int pos = s[i] - 'a' + 1;
		nivel = obtenerNodo(pos,nivel);
	}
	nivel = obtenerNodo(0,nivel);
	nivel->tam++;
}

void insertarStringsConFrecuencia(node* nivel, vector<stringConFrecuencia> *scf,string sActual){
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL){
			string sl = string(1,nivel->hijos[i]->letras);
			if(sl[0]=='$'){ // es un fin de palabra
				stringConFrecuencia insertar;
				insertar.s=sActual;
				insertar.frecuencia = nivel->hijos[i]->tam;
				scf->push_back(insertar);
				//cerr<< "se inserto en scf";
			}
			sActual += sl;	
			insertarStringsConFrecuencia(nivel->hijos[i],scf,sActual);
			sActual.pop_back();
		} 
	}
	return;
}

vector<stringConFrecuencia> Trie::obtenerStrings(string s,node* nivel){
	vector<stringConFrecuencia> scf;
	insertarStringsConFrecuencia(nivel,&scf,s);
	
	return scf;
}

vector<string> Trie::busqueda(string s,int k){
	int aux= s.size()+1;
	vector<string> resultado;
	vector<stringConFrecuencia> scf;
	do{
		aux--;
		node* nivel = nodoMasCercano(s,&aux);
		string stringAuxiliar;
		for(int i=0; i<aux; i++){
			stringAuxiliar+=s[i];
		}
		scf = obtenerStrings(stringAuxiliar,nivel);
	}while(k>scf.size());
	ordenarArr(&scf);
	cerr << "scf: " << endl;
	for(int i=0;i<scf.size();i++){
		cerr << scf[i].s << scf[i].frecuencia << " ";
	}
	cerr << endl;
	for(int i = 0; i<k;i++){
		resultado.push_back(scf[i].s);
		aumentarFrecuencia(scf[i].s); //ESTA MALO EL METODO
	}
	// Esto despues se borra, lo tengo aqui para probar
	return resultado;
	
	//crea un arreglo de strings desde la palabra mas usada(izquierda) a la menos usada 
	// esto se puede hacer dsps de recojer todas las palabras, simplemente comparo su frecuencia
	// (podria hacer un arreglo que guarde una structura con string y frecuencia)
}

void Trie::revisarTrie(node* nivel,string aux){
	cout << "nivel " << aux.size() << endl << "string ahora: " << aux << ":" << endl;
	for(int i=0; i<nivel->hijos.size(); i++){
		if(nivel->hijos[i] != NULL){
			imprimirLetras(nivel);
			string sl = string(1,nivel->hijos[i]->letras);
			aux += sl;	
			revisarTrie(nivel->hijos[i],aux);
			aux.pop_back();
		} 
	}
}

void Trie::verTrie(){
	string aux;
	revisarTrie(arbol,aux);
}
