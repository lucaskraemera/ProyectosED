#include "Trie.h"
#include <string>
#include <iostream>

using namespace std;

Trie::Trie(){
	this->arbol = new node();
}

Trie::~Trie(){
	// despues nos preocupamos del destructor
}

node* Trie::crearNodo(char caracter){
	node* puntero= new node();
	puntero->hijos.assign(27,NULL);
	cout << caracter << endl;
	//puntero->letras = NULL; // nose como inicializarlo xd
	puntero->tam=0;
	return puntero;
}

void Trie::desplazarVector(int j, vector<struct node*> vec){
	int n=vec.size();
	for(n;n>j;n++){
		vec[n]=vec[n-1];
	}
}

void Trie::insert(string s,int frecuencia){
	string sl; // string utilizada para ver el caracter de s como string para el metodo compare
	string aux; // el caracter a comparar del node
	int i,j; // declare los int pq tal vez los use afuera del for (solo el j pero declare el i igual porsiacaso)
	vector<struct node*> nivel = arbol->hijos; // nivel del vector en el que nos encontramos
	cout << "paso declaracion de variables del insert del trie" << endl;
	for(i=0;i<s.size();i++){ // recorrer a nivel de vector
		cout << i << endl;
		sl=s[i]; // tomar el caracter del string s a asignar/insertar
		for(j=0;j<nivel.size();j++){ // recorrer las letras dentro del nivel de vector que estamos
			if(nivel[j] == NULL){
				char caracter =sl[0];
				nivel[j] = crearNodo(caracter);	
				break;
			}
			aux = nivel[j]->letras; // ver la letra que esta ocupando el nodo
			//comparacion de caracteres
			if(sl.compare(aux) > 0)  continue; // sigamos, vamos en el orden correcto
			else if(sl.compare(aux) == 0) break; // las letras son las mismas, por lo que solo tenemos que seguir de nivel
			else{
				desplazarVector(j,nivel);
				char caracter =sl[0];
				nivel[j] = crearNodo(caracter);	
				break;
			}// caso que es menor (desplaszar todo a la derecha y colocarlo ahi)
		}
		nivel = nivel[j]->hijos; // pasar al siguiente nivel para la comparacion (estos fueron definidos en el for anterior)
	}
	cout << "paso for del insert del trie" << endl;
	// asignacion de caracter peso que siempre va al comienzo del arreglo y como estamos leyendo del diccionario, este nunca se va a encontrar anteriormente en el arreglo
	sl= '$'; 
	desplazarVector(0,nivel);
	nivel[0] = crearNodo(sl[0]);
	nivel[0]->tam = frecuencia;
}
