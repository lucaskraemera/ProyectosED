#include <vector>
#include <string>
#ifndef TRIE_H
#define TRIE_H
struct node {
    std::vector<struct node*> hijos;
    char letras;
    int tam;
};
#endif

using namespace std;

class Trie{
	private:
		node* arbol;
		node* crearNodo(char caracter);
		void desplazarVector(int pos, vector<struct node*> vec);
	public: 
		Trie();
		~Trie();
		void insert(string s,int frecuencia);
		//void pop();
		//int at(int pos);
		//int size();
};
