#include <string>
#include "Trie.h"

using namespace std;

class Predictor{
	private:
		Trie* t;
	public:
		Predictor();
		~Predictor();
		void insert(string s,int frecuencia);
		string* busqueda(string aBuscar);
		void imprimirResultados(ofstream archivoSalida);
};
