#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Controladora.h"

using namespace std;

struct auxlec{
	string s;
	int n; // frecuencia
};

int main(int argc, char *argv[]){
	//cout << "hola" << endl;
	if (argc!=3)
    {
        printf("Debes entregar 2 parametros\n");
        return 1;
    }
    cout << endl;
    cout << argv[1] << endl;
    cout << argv[2] << endl;
    
	ifstream entrada;
	ofstream salida;
	
	//asegurarse de que vengan los archivos requeridos
	/*
	entrada.open("busqueda.txt");
	if(!entrada){
		cout << "faltan archivos" << endl;
		return 0;
	}
	entrada.close();
	entrada.open("diccionario.txt");
	if(!entrada) return 0;
	salida.open("resultados.txt");s
	}
	*/
	// ifstream lectura << argv[2]
	// ofstream resultado << argv[3]
	// int k << argv[4]
	
	
	entrada.open(argv[1]);
	salida.open(argv[2]);
	
	
	Controladora* control = new Controladora();
	control->lecturaDiccionario(entrada);
	
	string palabra;
	int numero;
	string aux;

	cout << endl << "Lectura de entrada:" << endl;
	/*
	while(!entrada.eof()){
		entrada >> palabra;
		cout << palabra << endl;
		entrada >> aux;
		numero = stoi(aux);
		cout << aux << endl;
		cout << endl;
		// entregar para el constructor del stoi / guardarlo en algun puntero para usarlo despues
	}
	*/
	cout << "Pre delete control" << endl;
	delete control;
	
	entrada.close();
	salida.close();
	
	cout << "El proceso termino correctamente" << endl;
	
    return 0;   
} 
