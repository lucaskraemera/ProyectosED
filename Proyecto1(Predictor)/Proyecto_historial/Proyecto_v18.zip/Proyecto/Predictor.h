#include <string>
#include "Trie.h"

using namespace std;

class Predictor{
	private:
		Trie* t;
		void ordenarArr(vector<stringConFrecuencia>* scf);
	public:
		Predictor();
		~Predictor();
		void insert(string s,int frecuencia);
		vector<string> busqueda(string aBuscar,int k);
};
