#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

using namespace std;

int main(int argc, char** argv) {

	if(argc!=3){
		cout << "Dame el nombre del archivo y la cantidad de numeros a ingresar";
	}
	srand(time(NULL));
	int numero = stoi(argv[2]);
	ofstream salida;
	salida.open(argv[1]);
	
	for(int i=0;i<numero;i++){
		int nuevo = 1 + rand()%27;
		string aInsertar = to_string(nuevo);
		salida << aInsertar << "\n";
	}
	return 0;
}