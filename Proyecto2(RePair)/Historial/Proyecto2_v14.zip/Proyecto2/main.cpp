#include <iostream>
#include <fstream>
#include <time.h>
#include "mapRepair.h"
#include "heapRepair.h"
#include "pointerDoublyLinkedList.h"

using namespace std;
// preguntar destructor del mapa pq guarda punteros a nodos, forma de hacer que funcione el codigo(bools, usar varias variables), el grafico como debe ser, la notacion O(de cada metodo o solo en general?)
int main(int argc, char** argv) {
	if (argc!=3){
        cout << "Debes entregar 2 parametros, el archivo de texto con numeros y el rango de los numeros (entre 1 y el rango que tu entreges)" << endl;
        return 0;
    }
	
	//cout << "map re-pair:" << endl;
	//mapRepair* mapRe = new mapRepair();
	//mapRe->rePair(argv[1], stoi(argv[2]));
	//mapRe->print(); //imprime la linked list
	
	cout << endl << endl << "heap re-pair: " << endl;
	heapRepair* heapRe = new heapRepair();
	heapRe->rePair(argv[1], stoi(argv[2]));
	heapRe->print(); //imprime la linked list
	
	//cerr << "delete" << endl;// nose pq el programa a veces termina bien y a veces no (muere en delete)
	//falta arreglar delete
	//delete mapRe;
	delete heapRe;
	
	cout << "El proceso termino correctamente" << endl;
	return 0;
}
