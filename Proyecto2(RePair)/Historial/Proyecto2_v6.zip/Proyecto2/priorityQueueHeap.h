#include <vector>

using namespace std;

class priorityQueueHeap{

private:
	vector<pair<int,int>> _arr;
	void upHeap(int rank);
	void downHeap(int rank);
	bool esMenor(int nodoPadre,int nodoHijo);
public:
	priorityQueueHeap();
	~priorityQueueHeap();
	bool empty();
	int size();
	pair<int,int> top();
	void push(pair<int,int> par);
	void pop();
};
