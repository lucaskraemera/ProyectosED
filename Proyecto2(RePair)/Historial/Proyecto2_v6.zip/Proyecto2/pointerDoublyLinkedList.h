#ifndef POINTERDOUBLYLINKEDLIST_H
#define POINTERDOUBLYLINKEDLIST_H

#include "pointerIterador.h"

class pointerDoublyLinkedList{
	private:
		pointerIntNode *head;
		pointerIntNode *tail;
		pointerIntNode* crearNodo(pointerIntNode* next, pointerIntNode* prev,int symbolo);
		int size();
		bool empty();
	public:
		pointerDoublyLinkedList();
		~pointerDoublyLinkedList();
		void insertFirst(int symbolo);
		void insertLast(int symbolo);
		void insertAfterNode(int symbolo, pointerIntNode* nodo);
		void insertBeforeNode(int symbolo, pointerIntNode* nodo);
		void remove(pointerIntNode* nodo);
		int getElement(pointerIntNode* nodo);
		void setPunterosIguales(pointerIntNode* nodoAnteriorigual, pointerIntNode* nodoActualIgual);
		pointerIntNode* getHead();
		pointerIntNode* getTail();
		pointerIterador begin();
};

#endif
