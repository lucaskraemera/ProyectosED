#ifndef ITERADOR_H
#define ITERADOR_H

struct intNode{
	int numero;
	intNode* prev;
	intNode* next;
};

class iterador{
	private:
		intNode* actual;
		intNode* end;
	public:	
		iterador(intNode* begin, intNode* fin);
		~iterador();
		bool hasNext();
		int next();
		intNode* getNode();
};

#endif
