#include "pointerDoublyLinkedList.h"
#include "priorityQueueHeap.h"
#include <map>

using namespace std;

class heapRepair{
	private:
		pointerDoublyLinkedList* list;
		priorityQueueHeap* heap; // reset o simplemente  delete y new
		map<pair<int,int>, pair<pointerIntNode*,pointerIntNode*>> mapa;
		int sigma;
		void setSequence(char* text, int range);
		pair< pair<int,int>, pair<pointerIntNode*,pointerIntNode*> > firstRead();
		void replaceSequence(pair <pair<int,int>,pair<pointerIntNode*,pointerIntNode*>>);
		// list guarda punteros del anterior elemento y posterior elemento igual,
		// mientras que el heap guardara la primera ocurrencia del elemento y la ultima, con el fin de poder un for 
		// desde la primera ocurrencia hasta la ultima, utilizando el nextNode de la linked list
		// para recorrerla eficientemente
	public:
		heapRepair();
		~heapRepair();
		void rePair(char* text, int range);
		void print();
};
