#include <iostream>
#include "priorityQueueHeap.h"
#include <vector>

using namespace std;

priorityQueueHeap::priorityQueueHeap(){
}

priorityQueueHeap::~priorityQueueHeap(){
}

bool priorityQueueHeap::esMenor(int nodoPadre, int nodoHijo){
	if(_arr[nodoPadre].first < _arr[nodoHijo].first) return true;
	else if(_arr[nodoPadre].first == _arr[nodoHijo].first && _arr[nodoPadre].second < _arr[nodoHijo].second) return true;
	return false;	
}


void priorityQueueHeap::upHeap(int rank){
	if(rank == 0) return; // si estoy en la raiz, no puedo volver a hacerlo
	int nivelPadre = (rank-1)/2;
	if(esMenor(nivelPadre,rank)){
		//cout << "upheap swap entre(nivel superior, nivel inferior) " << _arr[nivelMayor] << " y " << _arr[rank] << endl;
		pair<int,int> aux = _arr[rank];
		_arr[rank] = _arr[nivelPadre];
		_arr[nivelPadre] = aux;
		upHeap(nivelPadre);
	}
	return;
}

void priorityQueueHeap::downHeap(int rank){
	int posHijo = 2*rank + 1; // posHijo es el hijo izquierdo del nodo
	int size = _arr.size();
	if(posHijo >= size) return; // el nodo no tiene hijo
	if(posHijo+1 < size && esMenor(posHijo,posHijo+1)) posHijo = posHijo + 1;
	if(esMenor(rank,posHijo)){
		//cout << "downheap swap entre(nivel superior y nivel inferior) " << _arr[rank] << " y " << _arr[posHijo] << endl;
		pair<int,int> aux = _arr[rank];
		_arr[rank] = _arr[posHijo];
		_arr[posHijo] = aux;
		downHeap(posHijo);
	}
	return;
}

bool priorityQueueHeap::empty(){
	return _arr.empty();
}

int priorityQueueHeap::size(){
	return _arr.size();
}

pair<int,int> priorityQueueHeap::top(){
	return _arr[0];
}

void priorityQueueHeap::push(pair<int,int> par){
	_arr.push_back(par);
	upHeap(_arr.size()-1);
}

void priorityQueueHeap::pop(){
	_arr[0]=_arr[_arr.size()-1];
	_arr.pop_back();
	downHeap(0);
}
