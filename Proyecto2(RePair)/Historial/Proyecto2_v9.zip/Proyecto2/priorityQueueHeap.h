#include <vector>
#include "pointerDoublyLinkedList.h"

using namespace std;

struct infoNodo{
	pointerIntNode* primerIgual;
	pointerIntNode* ultimoIgual;
	int posHeap;
};

struct nodoHeap{
	int frecuencia;
	pair<int, int> par;
	infoNodo* punteroMapa;	
};

class priorityQueueHeap{

private:
	vector<nodoHeap> _arr;  //Almacena la frecuencia como clave, y los pares
	void upHeap(int rank);
	void downHeap(int rank);
	bool esMenor(int nodoPadre,int nodoHijo);
public:
	priorityQueueHeap();
	~priorityQueueHeap();
	bool empty();
	int size();
	nodoHeap top();
	void push(pair<int,int> par, infoNodo* pointer);
	void pop();
	void aumentarClave(int rank);
	void disminuirClave(int rank);
	void print();
};
