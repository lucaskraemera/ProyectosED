#include <iostream>
#include <fstream>
#include <time.h>
#include "mapRepair.h"
#include "heapRepair.h"
#include "pointerDoublyLinkedList.h"

using namespace std;

//dudas :
//que pasa si al reemplazar la cadena 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1(a la mitad de la cadena), que pasa con los s s s s s s, me refiero a los punteros anteriorIgual y siguienteIgual
//se generan errores en los borados, produce un error en la frecuencia real del par
//como mantener realmente actualizado la primera y ultima ocurrencia

int main(int argc, char** argv) {
	if (argc!=3){ // asegurarse que entregue un fichero de texto
        cout << "Debes entregar 2 parametros, el archivo de texto con numeros y el rango de los numeros (entre 1 y el rango que tu entreges)" << endl;
        return 0;
    }
	
	cout << "map re-pair:" << endl;
	mapRepair* mapRe = new mapRepair();
	mapRe->rePair(argv[1], stoi(argv[2]));
	mapRe->print();
	
	cout << endl << endl << "heap re-pair: " << endl;
	heapRepair* heapRe = new heapRepair();
	heapRe->rePair(argv[1], stoi(argv[2]));
	heapRe->print();
	
	//delete mapRe;
	delete heapRe;
	
	cout << "El proceso termino correctamente" << endl;
	return 0;
}
