#include <iostream>
#include <fstream>
#include <time.h>
#include "mapRepair.h"
#include <string>

using namespace std;

int main(int argc, char** argv) {
	if (argc!=3){
        cout << "Debes entregar 2 parametros, el archivo de texto con numeros y el rango de los numeros (entre 1 y el rango que tu entreges)" << endl;
        return 0;
    }
	
	mapRepair* mapRe = new mapRepair();
	//mapRe->rePair(argv[1], stoi(argv[2]));
	//mapRe->print(); //imprime la linked list
	
	doublyLinkedList* lista = new doublyLinkedList();
	
	intNode* actualNode = lista->getHead();
	
	lista->insertLast(1);
	lista->insertLast(2);
	lista->insertLast(3);
	lista->insertLast(8);
	lista->insertLast(121);
	
	actualNode = actualNode->next->next->next->prev;
	lista->insertBeforeNode(-1,actualNode);
	lista->insertAfterNode(-3,actualNode);
	
	iterador it = lista->begin();
	while(it.hasNext()) {
		cout << it.next() << endl;
	}
	
	return 0;
}
