#include "mapRepair.h"
#include <fstream>
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <utility>
#include <vector>

using namespace std;

mapRepair::mapRepair(){
	this->list = new doublyLinkedList(); // nose si dejar el new aqui, ya que hado delete y new en set Sequence
	this->sigma;
	this->mapa;
}

mapRepair::~mapRepair(){
	delete list;
}

void mapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new doublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	while(!lectura.eof()){
		int symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}



pair<int,int> mapRepair::firstRead(){
	while(!mapa.empty()){
		mapa.erase(mapa.begin());
	}
	
	//hacer la lectura
	iterador it = list->begin();
	pair<int,int> actualPair;
	if(it.hasNext()) actualPair.second = it.next(); 
	while(it.hasNext()){
		actualPair.first = actualPair.second;
		actualPair.second = it.next();
		mapa[actualPair] = mapa.find(actualPair)->second + 1; // SI EL TEXTO NO SE COMPRIME, ENTONCES ESTO NO FUNCIONAAAAAAAAAAAAAAAAAA
		//algoritmo de colocar los symbolos en el map y aumentar su frecuencia
	}

	//BUSCAMOS LA CLAVE QUE TENGA LA MAYOR FRECUENCIA
	map<pair<int,int>,int>::iterator it2;
	int mayor=0;
	pair<int,int> pairMayor;
	pair<pair<int,int>,int> parActual;

	for(it2=mapa.begin(); it2!=mapa.end(); it2++){
		parActual = *it2;
		if(parActual.second > mayor || (parActual.second == mayor && esMenor(pairMayor, parActual.first))){
			mayor = parActual.second;
			pairMayor = parActual.first;
		}
	}

	if(mayor>1) return pairMayor;
	else{
		actualPair.first = 0;
		return actualPair;
	}
}

bool mapRepair::esMenor(pair<int,int> p1, pair<int,int> p2){
	if(p1.first < p2.first) return true;
	else if(p1.first==p2.first && p1.second < p2.second) return true;
	return false;
}

void mapRepair::replaceSequence(pair<int,int> par){
	pair<int,int> listPar;
	iterador it = list->begin();
	while(it.hasNext()){
		listPar.first = listPar.second;
		listPar.second = it.next();
		if(listPar == par){
			intNode* nodeAux = it.getNode();
			list->remove(nodeAux->prev);
			list->remove(nodeAux->prev);
			list->insertBeforeNode(sigma, nodeAux);
		}
	}
}

string mapRepair::rePair(char* text, int range){ //MALA
	this->setSequence(text,range);
	pair<int,int> par; //PREGUNTAR SI SE PUEDE USAR NULLPTR, SINO LO DEJO COMO 1 CARACTER NMS Y REVIZO ESO
	par = this->firstRead();
	while(par.first != 0){ // se podria verificar si el segundo caracter de pair es nullptr, nose PREGUNTAR
		replaceSequence(par);
		sigma++;
		par = this->firstRead();	
	}
	return NULL;
}

void mapRepair::print(){
	iterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}
