#include "heapRepair.h"
#include <iostream>
#include <fstream>

using namespace std;

heapRepair::heapRepair(){
	this->list = new pointerDoublyLinkedList();
	//this.mapa;
	//this->heap;
	//this.sigma;
}

heapRepair::~heapRepair(){
	delete list;
}

void heapRepair::destructorHeapyMap(){
	delete heap;
	map<pair<int,int>, infoNodo*>::iterator it = mapa.begin();
	for(it;it!=mapa.end();it++){
		delete it->second;
	}
}

void heapRepair::imprimirPar(pointerIntNode* puntero){
	if(puntero == nullptr) cerr << "null" << endl;
	else cerr << puntero->prev->numero << " " << puntero->numero << endl;
}

void heapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new pointerDoublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	int symbolo;
	while(lectura >> symbolo){
		list->insertLast(symbolo);
	}
}

void heapRepair::aumentarFrecuencia(pair<int,int> actualPair, pointerIntNode* puntero){
	map<pair<int,int>,infoNodo*>::iterator iterar = mapa.find(actualPair);
	if(iterar!=mapa.end()){ // si find retorna un iterador en mapa.end() significa que no encontro la clave
		//se actualiza la informacion del par encontrado y del par anterior
		//cerr << "antes aumentarClave"<<endl;
		infoNodo* aux = iterar->second;
		if(aux->primerIgual!=nullptr){
			puntero->anteriorIgual = aux->ultimoIgual;
			aux->ultimoIgual->siguienteIgual = puntero;
			aux->ultimoIgual = puntero;
		}else{	
			aux->primerIgual = puntero;
			aux->ultimoIgual = puntero;
		}
		
		heap->aumentarClave(aux->posHeap);
		//cerr << "termino aumentarClave"<<endl;
	}else{
		//en caso de no existir, crea e inicializa el nodo creado

		//cerr << "antes push"<<endl;
		infoNodo* aInsertar = new infoNodo();
		//cerr << "el error sera el new?"<<endl;

		aInsertar->primerIgual = puntero;
		aInsertar->ultimoIgual = puntero;
		aInsertar->posHeap = heap->size();
		heap->push(actualPair,aInsertar);
		//cerr << "termino push"<<endl;
		mapa.insert(make_pair(actualPair,aInsertar));
	}
	//cerr << "despues a"<<endl;
}

void heapRepair::firstRead(){
    //nos aseguramos de tener las variables "limpias" antes de comenzar el proceso
    this->heap = new priorityQueueHeap();
    //bool aux= false;
    //hacer la lectura
    pointerIterador it = list->begin();
    pair<int,int> actualPair;
    if(it.hasNext()) actualPair.second = it.next();
    while(it.hasNext()){
    	int siguientee = it.next();
        //cerr << aux << endl;
        //if(actualPair.first == actualPair.second == siguientee && aux){
        //    aux = false;
        //    continue;
        //}
        actualPair.first = actualPair.second;
        actualPair.second = siguientee;
        aumentarFrecuencia(actualPair,it.getNode()->prev);
        //aux = true;
    }
    print();
    heap->print();
}

void heapRepair::actualizarPunteros(pointerIntNode* actual){
	pair<int,int> parActual = make_pair(actual->prev->numero,actual->numero);
	heap->disminuirClave(mapa[parActual]->posHeap);
	if(actual->siguienteIgual==nullptr){
		mapa[parActual]->ultimoIgual = actual->anteriorIgual;
	}
	else{
		actual->siguienteIgual->anteriorIgual = actual->anteriorIgual;
	}
	if(actual->anteriorIgual==nullptr){
		mapa[parActual]->primerIgual = actual->siguienteIgual;
	}
	else{
		actual->anteriorIgual->siguienteIgual = actual->siguienteIgual;
	}
}

void heapRepair::replaceSequence(){
	//reversePrint();
	cerr << "replace" << endl;
	pointerIntNode* actual = heap->top().punteroMapa->primerIgual;
	pair<int,int> parActual = heap->top().par;
	cerr << "par actual: " << parActual.first << " " << parActual.second << " con frecuencia: " << heap->top().frecuencia << endl;
	heap->pop();
	bool esCabeza = false;
	bool esCola = false;
	while(actual!=nullptr){
		print();
		pointerIntNode* nextReplace = actual->siguienteIgual;
		if(make_pair(actual->prev->numero,actual->numero) != parActual){
			actual = nextReplace;
			continue;
		}
		cerr << "antes de actualizar Punteros" << endl;
		reversePrint();
		if(actual->prev->prev = list->getHead()){
			cerr << "cabeza" << endl;
			esCabeza = true;
		}
		if(actual->next = list->getTail()) esCola = true;
		if(!esCabeza) actualizarPunteros(actual->prev);
		cerr << "dsps de actualizar aActual" << endl;
		reversePrint();
		if(!esCola) actualizarPunteros(actual->next);
		cerr << "dsps de actualizar sActual" << endl;
		reversePrint();
		//cerr << actual->prev->prev->prev->numero << endl;
		//while(1);
		esCabeza = false;
		reversePrint();
		list->insertAfterNode(sigma,actual);
		reversePrint();
		actual = actual->next;
		list->remove(actual->prev->prev);
		reversePrint();
		list->remove(actual->prev);
		reversePrint();
		if(!esCabeza)aumentarFrecuencia(make_pair(actual->prev->numero,actual->numero),actual);
		if(!esCola)aumentarFrecuencia(make_pair(actual->numero,actual->next->numero),actual->next);
		print();
		//heap->print();
		actual = nextReplace;
	}
	sigma++;
}

void heapRepair::rePair(char* text, int range){
	setSequence(text,range);
	firstRead();
	ofstream salida;
	salida.open("heapResultados.txt");
	guardarListaInicial(salida);
	cerr << "paso first read" << endl;
	while(compresible()){
		guardarResultados(salida);
		replaceSequence();
	}
	//heap->print();
	destructorHeapyMap();

	return;
}

bool heapRepair::compresible(){
	//cerr << "compresible?" << endl;
	//if(heap->empty()) //cerr << "vacio" << endl;
	//cerr << heap->top().frecuencia << " frecuencia y " << heap->top().par.first << heap->top().par.second << " de par" << endl;
	if(!heap->empty() && heap->top().frecuencia > 1)
		return true;
	else
		return false;
}

void heapRepair::reversePrint(){
	pointerIntNode* act = list->getTail();
	while(act!=nullptr){
		cerr << act->numero << " ";
		act = act->prev;
	}
	cerr << endl;
}

void heapRepair::print(){
	pointerIterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}

void heapRepair::guardarListaInicial(ofstream & salida){
	salida << "lista inicial: " << endl;
	pointerIterador it = list->begin();
	while(it.hasNext()){
		salida << it.next() << " ";
	}
	salida << endl;
}

void heapRepair::guardarResultados(ofstream & salida){
	salida << "lista comprimida: " << heap->top().par.first << " " << heap->top().par.second << "sigma" << sigma << endl;
	pointerIterador it = list->begin();
	while(it.hasNext()){
		salida << it.next() << " ";
	}
	salida << endl;
}

