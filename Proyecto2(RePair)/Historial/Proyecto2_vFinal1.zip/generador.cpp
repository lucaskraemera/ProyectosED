#include <iostream>
#include <fstream>
#include <string>
#include <time.h>

using namespace std;

int main(int argc, char** argv) {

	if(argc!=3){
		cout << "inserte el nombre del archivo diccionario y la cantidad de palabras del diccionario";
	}
	srand(time(NULL));
	int numero = stoi(argv[2]);
	ofstream salida;
	salida.open(argv[1]);
	int anterior = 0;
	for(int i=0;i<numero;i++){
		int nuevo = 1 + rand()%27;
		if(nuevo!=anterior){
			string aInsertar = to_string(nuevo);
			salida << aInsertar << "\n";
		}else
			i--;
		anterior = nuevo;
	}
	return 0;
}
