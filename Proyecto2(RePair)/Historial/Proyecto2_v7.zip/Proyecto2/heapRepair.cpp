#include "heapRepair.h"
#include <iostream>
#include <fstream>

using namespace std;

heapRepair::heapRepair(){
	this->list;
	this->mapa;
	this->heap;
	this->sigma;
}

heapRepair::~heapRepair(){
	delete list;
	delete heap;
}

void heapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new pointerDoublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	while(!lectura.eof()){
		int symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}

//QUEREMOS DEVOLVER LA NUEVA POSICION DEL PAR DESPUÉS DE LOSSSSS UPHEAP NECESARIOSSSS 
void heapRepair::firstRead(){
	
	this->heap = new priorityQueueHeap();
	while(!mapa.empty()){
		mapa.erase(mapa.begin());
	}

	//hacer la lectura
	pointerIterador it = list->begin();
	pair < pair<int,int>, infoNodo > actualPair;
	if(it.hasNext()) actualPair.first.second = it.next(); 
	while(it.hasNext()){
		actualPair.first.first = actualPair.first.second;
		actualPair.first.second = it.next();
		infoNodo aux = mapa.find(actualPair);
		if(aux!=null){
			heap->aumentarClave(aux.posHeap);
			pointerIntNode* puntero = it.getNode();
			puntero.anteriorIgual = aux.ultimoIgual
			aux.ultimoIgual.siguienteIgual = puntero;
			aux.ultimoIgual = puntero;
			aux.posHeap = heap->aumentarClave(aux.posHeap); //aumentarclave debe devolver la posicion
		}else{
			infoNodo aInsertar = new infoNodo();
			pointerIntNode* puntero = it.getNode();
			aInsertar.primerIgual = puntero;
			aInsertar.ultimoIgual = puntero;
			aInsertar.posHeap = heap->size();
			heap->push(actualPair.first);
		}
	}
}

void heapRepair::replaceSequence(){

}

void heapRepair::rePair(char* text, int range){
	setSequence(text,range);

	firstRead();
	cerr << "firstRead" << endl;
	ofstream salida; // PREGUNTAR SI MANTENERLO O BORRARLO
	salida.open("heapResultados.txt");
	salida << "secuencia inicial: ";
	while(true){
		if(compresible()) break;
	}
	delete this->mapa;
	delete this->heap;
	return;
}

void heapRepair::print(){
	pointerIterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}
bool heapRepair::compresible(){
	if(!heap->empty() && heap->top().first > 1)
		return true;
	else
		return false;
}

