#include "heapRepair.h"
#include <iostream>
#include <fstream>

using namespace std;

heapRepair::heapRepair(){
	this->list = new pointerDoublyLinkedList();
	//this.mapa;
	//this->heap;
	//this.sigma;
}

heapRepair::~heapRepair(){
	delete list;
}

void heapRepair::destructorHeapyMap(){
	delete heap;
	map<pair<int,int>, infoNodo*>::iterator it = mapa.begin();
	for(it;it!=mapa.end();it++){
		delete it->second;
	}
}

void heapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new pointerDoublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	while(!lectura.eof()){
		int symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}

void heapRepair::aumentarFrecuencia(pair<int,int> actualPair, pointerIntNode* puntero){
	// puntero es el puntero al con el que se esta trabajando(la position del actualPair en la lista)
	//cerr << "antes a"<<endl;
	map<pair<int,int>,infoNodo*>::iterator iterar = mapa.find(actualPair);
	if(iterar!=mapa.end()){ // si find retorna un iterador en mapa.end() significa que no encontro la clave
		//se actualiza la informacion del par encontrado y del par anterior
		//cerr << "antes aumentarClave"<<endl;
		infoNodo* aux = iterar->second;
		puntero->anteriorIgual = aux->ultimoIgual;
		aux->ultimoIgual->siguienteIgual = puntero;
		aux->ultimoIgual = puntero;
		heap->aumentarClave(aux->posHeap);
		//cerr << "termino aumentarClave"<<endl;
	}else{
		//en caso de no existir, crea e inicializa el nodo creado
		//cerr << "antes push"<<endl;
		infoNodo* aInsertar = new infoNodo();
		aInsertar->primerIgual = puntero;
		aInsertar->ultimoIgual = puntero;
		aInsertar->posHeap = heap->size();
		heap->push(actualPair,aInsertar);
		//cerr << "termino push"<<endl;
		mapa.insert(make_pair(actualPair,aInsertar));
	}
	//cerr << "despues a"<<endl;
}

void heapRepair::firstRead(){
	//nos aseguramos de tener las variables "limpias" antes de comenzar el proceso
	this->heap = new priorityQueueHeap();

	//hacer la lectura
	pointerIterador it = list->begin();
	pair<int,int> actualPair;
	if(it.hasNext()) actualPair.second = it.next();
	while(it.hasNext()){
		actualPair.first = actualPair.second;
		actualPair.second = it.next();
		aumentarFrecuencia(actualPair,it.getNode()->prev);
	}
}

void heapRepair::replaceSequence(){
	// inicializar primer puntero y booleanos auxiliares
	pointerIntNode* actual = heap->top().punteroMapa->primerIgual;
	pair<int,int> parActual = heap->top().par;
	heap->pop();
	bool esCabeza = false;
	bool esCola = false;
	while(actual!=nullptr){ // cuando llega a nullptr significa que termino de hacer la ultima ocurrencia
		if(make_pair(actual->prev->numero, actual->numero) != parActual){
			//CASO IMPORTANTE, pues si el par es el mismo symbolo/entero repetido y hay varios pares consecutivos genera un problema si no lo destinguimos
			actual = actual->siguienteIgual;
			continue;	
		}
		cerr << "par actual: " << parActual.first << " " << parActual.second << endl;
		pointerIntNode* nextReplace = actual->siguienteIgual; // para almacenar donde trabajar en el siguiete ciclo
		pointerIntNode* anteriorActual = actual->prev; // punteros que indican donde esta el par anterior y el par siguiente
		pointerIntNode* siguienteActual = actual->next;
		if(anteriorActual->prev == list->getHead()) esCabeza = true; // importante de ignorar caso en que la cabeza sea "incluida" dentro de un par
		if(!esCabeza){
			pair<int,int> parAnterior = make_pair(anteriorActual->prev->numero, anteriorActual->numero);
			cerr  << "Par Anterior: " << parAnterior.first << " " << parAnterior.second << endl;
			heap->disminuirClave(mapa[parAnterior]->posHeap);
			if(anteriorActual->anteriorIgual != nullptr){
				anteriorActual->anteriorIgual->siguienteIgual = anteriorActual->siguienteIgual;
			}else{
				mapa[parAnterior]->primerIgual = anteriorActual->siguienteIgual;
			}
			if(anteriorActual->siguienteIgual != nullptr){
				anteriorActual->siguienteIgual->anteriorIgual = anteriorActual->anteriorIgual;
			}else{
				mapa[parAnterior]->ultimoIgual = anteriorActual->anteriorIgual;
			}
		}
		
		if(siguienteActual == list->getTail()) esCola = true; // analogo al caso de la cabeza, pero en la cola
		if(!esCola){
			pair<int,int> parSiguiente = make_pair(siguienteActual->prev->numero, siguienteActual->numero);
			cerr  << "Par Siguiente: " << parSiguiente.first << " " << parSiguiente.second << endl;
			if(parSiguiente != parActual) heap->disminuirClave(mapa[parSiguiente]->posHeap);
			if(siguienteActual->anteriorIgual != nullptr){
				siguienteActual->anteriorIgual->siguienteIgual = siguienteActual->siguienteIgual;
			}else{
				mapa[parSiguiente]->primerIgual = siguienteActual->siguienteIgual;
			}
			if(siguienteActual->siguienteIgual != nullptr){
				siguienteActual->siguienteIgual->anteriorIgual = siguienteActual->anteriorIgual;
			}else{
				mapa[parSiguiente]->ultimoIgual = siguienteActual->anteriorIgual;
			}
		}
		
		// agregar el nuevo symbolo/entero y eliminar el par de la lista
		list->insertAfterNode(sigma,actual);
		actual = actual->next;
		list->remove(actual->prev);
		list->remove(actual->prev);
		if(!esCabeza) aumentarFrecuencia(make_pair(actual->prev->numero,actual->numero), actual);
		if(!esCola) aumentarFrecuencia(make_pair(actual->numero,actual->next->numero), actual->next); 
		
		esCabeza = false;// no es necesario cambiar el esCola pq estariamos en la ultima iteracion (restablecer el bool)
		esCola = false;
		actual = nextReplace;
	}
	sigma++; // actualizar el valor a reemplazar
	heap->pop(); // eliminar el par eliminado del heap
}

void heapRepair::rePair(char* text, int range){
	setSequence(text,range);
	firstRead();
	ofstream salida;
	salida.open("heapResultados.txt");
	guardarListaInicial(salida);
	while(compresible()){
		guardarResultados(salida);
		replaceSequence();
	}
	heap->print();
	destructorHeapyMap();

	return;
}

bool heapRepair::compresible(){
	//if(heap->empty()) //cerr << "vacio" << endl;
	//cerr << heap->top().frecuencia << " frecuencia y " << heap->top().par.first << heap->top().par.second << " de par" << endl;
	if(!heap->empty() && heap->top().frecuencia > 1)
		return true;
	else
		return false;
}

void heapRepair::print(){
	pointerIterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}

void heapRepair::guardarListaInicial(ofstream & salida){
	salida << "lista inicial: " << endl;
	pointerIterador it = list->begin();
	while(it.hasNext()){
		salida << it.next() << " ";
	}
	salida << endl;
}

void heapRepair::guardarResultados(ofstream & salida){
	salida << "lista comprimida: " << heap->top().par.first << " " << heap->top().par.second << "sigma" << sigma << endl;
	pointerIterador it = list->begin();
	while(it.hasNext()){
		salida << it.next() << " ";
	}
	salida << endl;
}

