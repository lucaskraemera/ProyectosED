#include "mapRepair.h"
#include <fstream>
#include <iostream>

using namespace std;

mapRepair::mapRepair(int num){
	this->list = new doublyLinkedList(); // nose si dejar el new aqui, ya que hado delete y new en set Sequence
	this->sigma = num;
	this->mapa;
}

mapRepair::~mapRepair(){
	
}

void mapRepair::setSequence(char* texto){
	delete this->list;
	this->list = new doublyLinkedList();
	ifstream lectura;
	lectura.open(texto);
	while(!lectura.eof()){
		char symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}

char* mapRepair::rePair(){
	if(list->size()<4) return nullptr; // no vale la pena hacer el algoritmo si tenemos menos de 2 pares de symbolos
}

void mapRepair::firstRead(){
	//reset mapa (no cacho bien como hacerlo sin puntero, ver si existe funcion reset o algo asi)
	//hacer la lectura
	iterador it = list->begin();
	while(it.hasNext()){
		//algoritmo de colocar los char en el map y aumentar su frecuencia
	}
}

void mapRepair::replaceSequence(char* pair){
	
}
