#include <iostream>
#include <fstream>
#include <time.h>
#include "mapRepair.h"

using namespace std;

int main(int argc, char** argv) {
	if (argc!=3){
        cout << "Debes entregar 2 parametros, el archivo de texto con numeros y el rango de los numeros (entre 1 y el rango que tu entreges)" << endl;
        return 0;
    }
	
	mapRepair* mapRe = new mapRepair(stoi(argv[2]));
	
	doublyLinkedList* lista = new doublyLinkedList();
	
	lista->insertLast('1');
	lista->insertLast('2');
	lista->insertLast('3');
	lista->insertLast('a');
	lista->insertLast('s');
	
	iterador it = lista->begin();
	while(it.hasNext()) {
		cout << it.next() << endl;
	}
	
	return 0;
}
