#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

#include "iterador.h"

class doublyLinkedList{
	private:
		charNode *head;
		charNode *tail;
		charNode* crearNodo(charNode* next, charNode* prev,char symbolo);
	public:
		doublyLinkedList();
		~doublyLinkedList();
		void insertFirst(char symbolo);
		void insertLast(char symbolo);
		void insertAfterNode(char symbolo, charNode* nodo);
		void insertBeforeNode(char symbolo, charNode* nodo);
		void remove(charNode* nodo);
		char getElement(charNode* nodo);
		int size();
		bool empty();
		charNode* getHead();
		charNode* getTail();
		iterador begin();
};

#endif
