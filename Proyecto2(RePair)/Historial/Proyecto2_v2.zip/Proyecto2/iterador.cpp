#include "iterador.h"

iterador::iterador(charNode* begin, charNode* fin){
	this->actual = begin->next;
	this->end = fin;
}

iterador::~iterador(){
	actual = nullptr;
	end = nullptr; // esto lo hago para asegurame de que no se borre ni la lista ni el nodo de la lista
	delete actual; 
	delete end; //PUEDE TRAER PROBLEMAS OJO Preguntar que pasa con el delete en este caso
}

bool iterador::hasNext(){
	if (actual == end) return false;
	return true;
}

char iterador::next(){
	char elemento = actual->caracter;
	actual = actual->next;
	return elemento;
}
