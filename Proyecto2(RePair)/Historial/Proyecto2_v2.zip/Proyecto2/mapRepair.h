#include "doublyLinkedList.h"
#include <fstream>
#include <iostream>
#include <bits/stdc++.h>

using namespace std;

class mapRepair{
	private:
		doublyLinkedList* list;
		map<string,int> mapa;
		int sigma;
		void firstRead();
		void replaceSequence(char* pair);
	public:
		mapRepair(int num);
		~mapRepair();
		void setSequence(char*texto);
		char* rePair();
};
