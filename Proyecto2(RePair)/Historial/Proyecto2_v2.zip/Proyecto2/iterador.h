#ifndef ITERADOR_H
#define ITERADOR_H

struct charNode{
	char caracter;
	charNode* prev;
	charNode* next;
};

class iterador{
	private:
		charNode* actual;
		charNode* end;
	public:	
		iterador(charNode* begin, charNode* fin);
		~iterador();
		bool hasNext();
		char next();
};

#endif
