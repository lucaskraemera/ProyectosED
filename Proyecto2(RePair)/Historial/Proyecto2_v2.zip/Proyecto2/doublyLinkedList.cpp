#include "doublyLinkedList.h"

doublyLinkedList::doublyLinkedList(){
	this->head = crearNodo(nullptr,nullptr,0);
	this->tail = crearNodo(nullptr,head,0);
	head->next = tail;	
}

doublyLinkedList::~doublyLinkedList(){
	//delete todo;
	delete this->head;
	delete this->tail;
}

charNode* doublyLinkedList::crearNodo(charNode* next,charNode* prev,char symbolo){
	charNode* aux= new charNode();
	aux->caracter = symbolo;
	aux->next=next;
	aux->prev=prev;
}

void doublyLinkedList::insertFirst(char symbolo){
	charNode* aux = crearNodo(head->next,head,symbolo); // creas el nodo
	head->next = aux; // asignas al puntero de la cabeza next como aux
	aux->next->prev = aux;  // asignas al puntero prev de la ex primera posicion como el nodo creado 
}

void doublyLinkedList::insertLast(char symbolo){
	charNode* aux = crearNodo(tail,tail->prev,symbolo);
	tail->prev = aux;
	aux->prev->next = aux; 
}

void doublyLinkedList::insertAfterNode(char symbolo, charNode* nodo){
	charNode* aux = crearNodo(nodo->next,nodo,symbolo);
	nodo->next = aux;
	aux->next->prev= aux;
}

void doublyLinkedList::insertBeforeNode(char symbolo, charNode* nodo){
	charNode* aux = crearNodo(nodo,nodo->prev,symbolo);
	nodo->prev = aux;
	aux->prev->next= aux;
}

void doublyLinkedList::remove(charNode* nodo){ 
	// nose si restringir el remove de head y tail: if(nodo== head || nodo == tail) return;
	nodo->next->prev = nodo->prev;
	nodo->prev->next = nodo->next;
	delete nodo;
}

char doublyLinkedList::getElement(charNode* nodo){
	return nodo->caracter;
}

int doublyLinkedList::size(){
	int i = 0;
	charNode* actual = head->next;
	for(actual;actual!=tail;actual = actual->next) i++;
	return i;
}

bool doublyLinkedList::empty(){
	if(head->next == tail) return true;
	else return false;
}

charNode* doublyLinkedList::getHead(){
	return head;
}

charNode* doublyLinkedList::getTail(){
	return tail;
}

iterador doublyLinkedList::begin(){
	iterador* it = new iterador(head,tail);
	return *it;
}
