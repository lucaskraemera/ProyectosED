#include "mapRepair.h"
#include <fstream>
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <utility>

using namespace std;

mapRepair::mapRepair(){
	this->list = new doublyLinkedList(); // nose si dejar el new aqui, ya que hado delete y new en set Sequence
	this->sigma;
	this->mapa;
}

mapRepair::~mapRepair(){
	delete list;
}

void mapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new doublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	while(!lectura.eof()){
		int symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}



pair<int,int> mapRepair::firstRead(){
	//reset mapa (no cacho bien como hacerlo sin puntero, ver si existe funcion reset o algo asi)
	
	//hacer la lectura
	iterador it = list->begin();
	pair<int,int> actualPair;
	if(it.hasNext()) actualPair.second = it.next(); //nose si agregar el if pq no hago el algoritmo si hay menos de 4 caracteres en la lista 
	while(it.hasNext()){
		actualPair.first = actualPair.second;
		actualPair.second = it.next();
		mapa.insert(make_pair(actualPair,1));
		//algoritmo de colocar los symbolos en el map y aumentar su frecuencia
	}
	
	// se podria usar un currentMayor que almacena lugar la frecuencia y el string del actual del mapa
	// if la frecuencia de currentMayor es mas grande que 1 return currentMayorString;
	// else 
	return make_pair(0,0);
}

void mapRepair::replaceSequence(pair<int,int> par){
	pair<int,int> listPar;
	iterador it = list->begin();
	while(it.hasNext()){
		listPar.first = listPar.second;
		listPar.second = it.next();
		if(listPar == par){
			intNode* nodeAux = it.getNode();
			list->remove(nodeAux->prev);
			list->remove(nodeAux->prev);
			list->insertBeforeNode(sigma, nodeAux);
		}
	}
}

string mapRepair::rePair(char* text, int range){ //MALA
	this->setSequence(text,range);
	pair<int,int> par; //PREGUNTAR SI SE PUEDE USAR NULLPTR, SINO LO DEJO COMO 1 CARACTER NMS Y REVIZO ESO
	par = this->firstRead();
	while(par.first != 0){ // se podria verificar si el segundo caracter de pair es nullptr, nose PREGUNTAR
		replaceSequence(par);
		sigma++;
		par = this->firstRead();	
	}
	return NULL;
}

void mapRepair::print(){
	iterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}
