#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

#include "iterador.h"

class doublyLinkedList{
	private:
		intNode *head;
		intNode *tail;
		intNode* crearNodo(intNode* next, intNode* prev,int symbolo);
		int size();
		bool empty();
	public:
		doublyLinkedList();
		~doublyLinkedList();
		void insertFirst(int symbolo);
		void insertLast(int symbolo);
		void insertAfterNode(int symbolo, intNode* nodo);
		void insertBeforeNode(int symbolo, intNode* nodo);
		void remove(intNode* nodo);
		int getElement(intNode* nodo);
		intNode* getHead();
		intNode* getTail();
		iterador begin();
};

#endif
