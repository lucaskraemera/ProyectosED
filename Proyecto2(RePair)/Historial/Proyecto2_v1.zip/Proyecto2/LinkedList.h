#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class LinkedList {
	public:
		virtual void insert(int) = 0;
		virtual void remove() = 0;
		virtual int getElement(int) = 0;
		virtual int size() = 0;
		virtual bool empty() = 0; 
		// int start();
};

#endif
