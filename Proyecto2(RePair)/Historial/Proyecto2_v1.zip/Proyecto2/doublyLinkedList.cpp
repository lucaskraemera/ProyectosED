#include "doublyLinkedList.h"

doublyLinkedList::doublyLinkedList(){
	this->head = crearNodo(nullptr,nullptr,0);
	this->tail = crearNodo(nullptr,head,0);
	head->next = tail;	
}

doublyLinkedList::~doublyLinkedList(){
	//delete todo;
	delete this->head;
	delete this->tail;
}

intNode* doublyLinkedList::crearNodo(intNode* next,intNode* prev,int num){
	intNode* aux= new intNode();
	aux->n= num;
	aux->next=next;
	aux->prev=prev;
}

void doublyLinkedList::insertFirst(int numero){
	
}

void doublyLinkedList::insertLast(int numero){
	
}

void doublyLinkedList::insertAfterNode(int numero, intNode* nodo){
	
}

void doublyLinkedList::insertBeforeNode(int numero, intNode* nodo){
	
}

void doublyLinkedList::remove(intNode* nodo){
	
}

int doublyLinkedList::getElement(intNode* nodo){
	return 5;
}

int doublyLinkedList::size(){
	return 5;
}

bool doublyLinkedList::empty(){
	return true;
}
