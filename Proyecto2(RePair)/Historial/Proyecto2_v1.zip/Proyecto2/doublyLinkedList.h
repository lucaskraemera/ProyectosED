#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

struct intNode{
	int n;
	intNode *prev;
	intNode *next;
};

class doublyLinkedList{
	private:
		intNode *head;
		intNode *tail;
		intNode* crearNodo(intNode* next, intNode* prev,int num);
	public:
		doublyLinkedList();
		~doublyLinkedList();
		void insertFirst(int numero);
		void insertLast(int numero);
		void insertAfterNode(int numero, intNode* nodo);
		void insertBeforeNode(int numero, intNode* nodo);
		void remove(intNode* nodo);
		int getElement(intNode* nodo);
		int size();
		bool empty();
};

#endif
