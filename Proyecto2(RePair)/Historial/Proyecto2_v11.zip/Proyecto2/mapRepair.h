#include "doublyLinkedList.h"
#include <fstream>
#include <iostream>
#include <bits/stdc++.h>
#include <string>
#include <utility>

using namespace std;

class mapRepair{
	private:
		doublyLinkedList* list;
		map<pair<int,int>,int> mapa;
		int sigma;
		void setSequence(char* text, int range);
		pair<int,int> firstRead();
		void replaceSequence(pair<int,int> par);
		bool esMenor(pair<int,int> p1, pair<int,int> p2);
		void guardarResultados(pair<int,int> par, ofstream & salida);
		void guardarCadenaInicial(ofstream & salida);
	public:
		mapRepair();
		~mapRepair();
		void rePair(char* text, int range);
		void print();
};
