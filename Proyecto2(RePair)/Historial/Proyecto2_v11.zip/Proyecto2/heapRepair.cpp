#include "heapRepair.h"
#include <iostream>
#include <fstream>

using namespace std;

heapRepair::heapRepair(){
	this->list = new pointerDoublyLinkedList();
	//this->mapa;
	//this->heap;
	//this->sigma;
}

heapRepair::~heapRepair(){
	delete list;
	delete heap;
	//DELETE DE LOS NODOS DEL MAP, PREGUNTAR AL ALEXIS
}

void heapRepair::setSequence(char* text, int range){
	delete this->list;
	this->list = new pointerDoublyLinkedList();
	this->sigma = range + 1;
	ifstream lectura;
	lectura.open(text);
	while(!lectura.eof()){
		int symbolo;
		lectura >> symbolo;
		list->insertLast(symbolo);
	}
}

void heapRepair::aumentarFrecuencia(pair<int,int> actualPair, pointerIntNode* puntero){
	map<pair<int,int>,infoNodo*>::iterator iterar = mapa.find(actualPair);
	if(iterar!=mapa.end()){
		infoNodo* aux = iterar->second;
		//pointerIntNode* puntero = it.getNode();
		puntero->anteriorIgual = aux->ultimoIgual;
		aux->ultimoIgual->siguienteIgual = puntero;
		aux->ultimoIgual = puntero;
		heap->aumentarClave(aux->posHeap); //aumentarclave debe devolver la posicion
	}else{
		infoNodo* aInsertar = new infoNodo();
		//pointerIntNode* puntero = it.getNode();
		aInsertar->primerIgual = puntero;
		aInsertar->ultimoIgual = puntero;
		aInsertar->posHeap = heap->size();
		heap->push(actualPair,aInsertar);
		//cerr << "actualPair: "<< heap->at(aInsertar->posHeap).par.first << " " << heap->at(aInsertar->posHeap).par.second << endl;
		mapa.insert(make_pair(actualPair,aInsertar));
	}
}

void heapRepair::firstRead(){
	
	this->heap = new priorityQueueHeap();
	while(!mapa.empty()){
		mapa.erase(mapa.begin());
	}

	//hacer la lectura
	pointerIterador it = list->begin();
	pair<int,int> actualPair;
	if(it.hasNext()) actualPair.second = it.next(); 
	while(it.hasNext()){
		actualPair.first = actualPair.second;
		actualPair.second = it.next();
		aumentarFrecuencia(actualPair,it.getNode()->prev);
	}
}

void heapRepair::replaceSequence(){
	infoNodo* mayorFrecuencia = heap->top().punteroMapa;
	pointerIntNode* actual = mayorFrecuencia->primerIgual;
	bool esCabeza = false;
	bool esCola = false;
	while(actual!=nullptr){
		if(make_pair(actual->prev->numero,actual->numero) != heap->top().par){
			actual=actual->siguienteIgual;
			continue;	
		} 
		//print();
		pointerIntNode* nextReplace = actual->siguienteIgual;
		pointerIntNode* anteriorActual = actual->prev;
		pointerIntNode* siguienteActual = actual->next;
		//cerr << actual->numero << endl;
		if(anteriorActual->prev==list->getHead()) esCabeza = true;
		if(!esCabeza){
			pair<int,int> parAnterior = make_pair(anteriorActual->prev->numero,anteriorActual->numero);
			//cerr  << "Par Anterior: " << parAnterior.first << " " << parAnterior.second << endl;
			heap->disminuirClave(mapa[parAnterior]->posHeap);
			if(anteriorActual->anteriorIgual!=nullptr){
				anteriorActual->anteriorIgual->siguienteIgual=anteriorActual->siguienteIgual;
			}
			if(anteriorActual->siguienteIgual!=nullptr){
				anteriorActual->siguienteIgual->anteriorIgual= anteriorActual->anteriorIgual;
			}
		}
		
		if(siguienteActual==list->getTail()) esCola = true;
		if(!esCola){
			pair<int,int> parSiguiente = make_pair(siguienteActual->prev->numero,siguienteActual->numero);
			//cerr  << "Par Siguiente: " << parSiguiente.first << " " << parSiguiente.second << endl;
			heap->disminuirClave(mapa[parSiguiente]->posHeap);
			if(siguienteActual->anteriorIgual!=nullptr){
				siguienteActual->anteriorIgual->siguienteIgual = siguienteActual->siguienteIgual;
			}
			if(siguienteActual->siguienteIgual!=nullptr){
				siguienteActual->siguienteIgual->anteriorIgual= siguienteActual->anteriorIgual;
			}
		}
		list->insertAfterNode(sigma,actual);
		actual = actual->next;
		list->remove(actual->prev);
		list->remove(actual->prev);
		if(!esCabeza){
			//cerr << actual->prev->numero << " " << actual->numero << endl;
			aumentarFrecuencia(make_pair(actual->prev->numero,actual->numero), actual);
		} 
		if(!esCola) aumentarFrecuencia(make_pair(actual->numero,actual->next->numero), actual->next); 
		
		esCabeza = false;// no es necesario pq estamos en la ultima iteracion (restablecer el bool)
		actual = nextReplace;
		//replace el webeo de punteros
		//disminuir frecuencia del par anterior y el siguiente LISTO 
		//FALTA DISMINUIR FRECUENCIA DEL PAR ACTUAL
		//cambiar los punteros sigIgual y anteriorIgual LISTO 
		//borrar el pairActual y reemplazarlo por el nuevo sigma Listo
		//a�adir los nuevos pares en el heap y mapa / aumentar su frecuencia LISTO esto lo hace aumentarFrecuencia
		//seguir con el ciclo
	}
	sigma++;
	heap->pop();
}

void heapRepair::rePair(char* text, int range){
	//cerr << "preSetSequence" << endl;
	setSequence(text,range);
	//print(); // DSPS SACARLO
	//cerr << "preFirstRead" << endl;
	firstRead();
	//cerr << "firstRead" << endl;
	ofstream salida; // PREGUNTAR SI MANTENERLO O BORRARLO
	salida.open("heapResultados.txt");
	salida << "secuencia inicial: ";
	while(true){
		//cerr << "entro" << endl;
		if(!compresible()) break;
		//cerr << "salio" << endl;
		//cerr << "print" << endl;
		//heap->print();
		replaceSequence();
	}
	//print();
	// agregar el delete del mapa
	delete this->heap;
	return;
}

void heapRepair::print(){
	pointerIterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}
bool heapRepair::compresible(){
	//if(heap->empty()) cerr << "vacio" << endl;
	//cerr << heap->top().frecuencia << " frecuencia y " << heap->top().par.first << heap->top().par.second << " de par" << endl;
	if(!heap->empty() && heap->top().frecuencia > 1)
		return true;
	else
		return false;
}

