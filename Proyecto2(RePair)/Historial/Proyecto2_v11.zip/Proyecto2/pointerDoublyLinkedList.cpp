#include "pointerDoublyLinkedList.h"

pointerDoublyLinkedList::pointerDoublyLinkedList(){
	this->head = crearNodo(nullptr,nullptr,0);
	this->tail = crearNodo(nullptr,head,0);
	head->next = tail;	
}

pointerDoublyLinkedList::~pointerDoublyLinkedList(){
	pointerIntNode* toRemove = head->next;
	while(toRemove!=tail){
		pointerIntNode* auxRemove = toRemove;
		toRemove = toRemove->next;
		delete auxRemove;
	}
	delete this->head;
	delete this->tail;
}

pointerIntNode* pointerDoublyLinkedList::crearNodo(pointerIntNode* next,pointerIntNode* prev,int symbolo){
	pointerIntNode* aux= new pointerIntNode();
	aux->numero = symbolo;
	aux->next=next;
	aux->prev=prev;
	aux->anteriorIgual=nullptr;
	aux->siguienteIgual=nullptr;
	return aux;
}

void pointerDoublyLinkedList::insertFirst(int symbolo){
	pointerIntNode* aux = crearNodo(head->next,head,symbolo); // creas el nodo
	head->next = aux; // asignas al puntero de la cabeza next como aux
	aux->next->prev = aux;  // asignas al puntero prev de la ex primera posicion como el nodo creado 
	aux->anteriorIgual=nullptr;
	aux->siguienteIgual=nullptr;
}

void pointerDoublyLinkedList::insertLast(int symbolo){
	pointerIntNode* aux = crearNodo(tail,tail->prev,symbolo);
	tail->prev = aux;
	aux->prev->next = aux;
	aux->anteriorIgual=nullptr;
	aux->siguienteIgual=nullptr;
}

void pointerDoublyLinkedList::insertAfterNode(int symbolo, pointerIntNode* nodo){
	pointerIntNode* aux = crearNodo(nodo->next,nodo,symbolo);
	nodo->next = aux;
	aux->next->prev= aux;
	aux->anteriorIgual=nullptr;
	aux->siguienteIgual=nullptr;
}

void pointerDoublyLinkedList::insertBeforeNode(int symbolo, pointerIntNode* nodo){
	pointerIntNode* aux = crearNodo(nodo,nodo->prev,symbolo);
	nodo->prev = aux;
	aux->prev->next= aux;
	aux->anteriorIgual=nullptr;
	aux->siguienteIgual=nullptr;
}

void pointerDoublyLinkedList::remove(pointerIntNode* nodo){ 
	// nose si restringir el remove de head y tail: if(nodo== head || nodo == tail) return;
	nodo->next->prev = nodo->prev;
	nodo->prev->next = nodo->next;
	delete nodo;
}

int pointerDoublyLinkedList::getElement(pointerIntNode* nodo){
	return nodo->numero;
}

int pointerDoublyLinkedList::size(){
	int i = 0;
	pointerIntNode* actual = head->next;
	for(actual;actual!=tail;actual = actual->next) i++;
	return i;
}

bool pointerDoublyLinkedList::empty(){
	if(head->next == tail) return true;
	else return false;
}

pointerIntNode* pointerDoublyLinkedList::getHead(){
	return head;
}

pointerIntNode* pointerDoublyLinkedList::getTail(){
	return tail;
}

void pointerDoublyLinkedList::setPunterosIguales(pointerIntNode* nodoAnteriorIgual, pointerIntNode* nodoActualIgual){
	nodoAnteriorIgual->siguienteIgual = nodoActualIgual;
	nodoActualIgual->anteriorIgual = nodoAnteriorIgual;
	nodoActualIgual->siguienteIgual = this->tail; // PREGUNTAR ALEXIS CUANDO VEAMOS CODIGO, porque sabemos cuando el coso termina gracias al puntero del heap
}

pointerIterador pointerDoublyLinkedList::begin(){
	pointerIterador* it = new pointerIterador(head,tail);
	return *it;
}
