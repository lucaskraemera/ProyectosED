#ifndef POINTERITERADOR_H
#define POINTERITERADOR_H

struct pointerIntNode{
	int numero;
	pointerIntNode* prev;
	pointerIntNode* next;
	pointerIntNode* primero;
	pointerIntNode* ultimo;
};

class pointerIterador{
	private:
		pointerIntNode* actual;
		pointerIntNode* end;
	public:	
		pointerIterador(pointerIntNode* begin, pointerIntNode* fin);
		~pointerIterador();
		bool hasNext();
		int next();
		pointerIntNode* getNode();
};

#endif
