#include "heapRepair.h"
#include <iostream>

using namespace std;

heapRepair::heapRepair(){
	this->list;
	this->heap;
	this->sigma;
}

heapRepair::~heapRepair(){
	
}

void heapRepair::setSequence(char* text, int range){
	
}

void heapRepair::replaceSequence(pair<int,int> par){
	
}

void heapRepair::rePair(char* text, int range){
	
}

void heapRepair::print(){
	pointerIterador it = list->begin();
	while(it.hasNext()){
		cout << it.next() << " ";
	}
	cout << endl;
}

