#include "pointerDoublyLinkedList.h"
#include "priorityQueueHeap.h"

using namespace std;

class heapRepair{
	private:
		pointerDoublyLinkedList* list;
		priorityQueueHeap* heap;
		int sigma;
		void setSequence(char* text, int range);
		void replaceSequence(pair<int,int> par);
	public:
		heapRepair();
		~heapRepair();
		void rePair(char* text, int range);
		void print();
};
