#include <iostream>
#include "priorityQueueHeap.h"
#include <vector>

using namespace std;

priorityQueueHeap::priorityQueueHeap(){
}

priorityQueueHeap::~priorityQueueHeap(){
}

void priorityQueueHeap::upHeap(int rank){
	if(rank == 0) return; // si estoy en la raiz, no puedo volver a hacerlo
	int nivelMayor = (rank-1)/2;
	if(_arr[nivelMayor]<_arr[rank]){
		//cout << "upheap swap entre(nivel superior, nivel inferior) " << _arr[nivelMayor] << " y " << _arr[rank] << endl;
		int aux = _arr[rank];
		_arr[rank] = _arr[nivelMayor];
		_arr[nivelMayor] = aux;
		upHeap(nivelMayor);
	}
	return;
}

void priorityQueueHeap::downHeap(int rank){
	int posHijo = 2*rank + 1; // posHijo es el hijo izquierdo del nodo
	int size = _arr.size();
	if(posHijo >= size) return; // el nodo no tiene hijo
	if(posHijo+1 < size & _arr[posHijo] < _arr[posHijo+1]) posHijo = posHijo + 1;
	if(_arr[rank]<_arr[posHijo]){
		//cout << "downheap swap entre(nivel superior y nivel inferior) " << _arr[rank] << " y " << _arr[posHijo] << endl;
		int aux = _arr[rank];
		_arr[rank] = _arr[posHijo];
		_arr[posHijo] = aux;
		downHeap(posHijo);
	}
	return;
}

bool priorityQueueHeap::empty(){
	return _arr.empty();
}

int priorityQueueHeap::size(){
	return _arr.size();
}

int priorityQueueHeap::top(){
	return _arr[0];
}

void priorityQueueHeap::push(int n){
	_arr.push_back(n);
	upHeap(_arr.size()-1);
}

void priorityQueueHeap::pop(){
	_arr[0]=_arr[_arr.size()-1];
	_arr.pop_back();
	downHeap(0);
}
