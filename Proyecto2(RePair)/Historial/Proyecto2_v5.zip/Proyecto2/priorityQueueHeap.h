#include <vector>

using namespace std;

class priorityQueueHeap{

private:
	vector<int> _arr;
	void upHeap(int rank);
	void downHeap(int rank);

public:
	priorityQueueHeap();
	~priorityQueueHeap();
	bool empty();
	int size();
	int top();
	void push(int);
	void pop();
};
